/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01_2;

/**
 *
 * @author chant
 */
public class Ejercicio4 {
    
    public static void main(String[] args) 
    {
        String nombre="Santiago";
        int edad=23;
        System.out.println("Nombre:"+nombre);
        System.out.println("edad:"+nombre);
    }
}
