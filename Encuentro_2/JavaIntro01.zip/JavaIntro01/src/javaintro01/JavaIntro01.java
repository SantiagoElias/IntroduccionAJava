/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01;

/**
 *
 * @author chant
 */
public class JavaIntro01 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        //System.out.println("Hola mundo"); //la linea 12 muestra el mensaje por pantalla al ejecutar el programa
        //String nombre;
        //int numero;
        //double decimales;
        //Ejercicio 1
        //float numero2;
        //int numero3;
        //double numero4;
        //String nombre2;
        //short numero6;
        //long numero7;
        String nombre2="Santiago";
        int edad=23;
        System.out.println("Nombre:"+nombre2);
        System.out.println("edad:"+edad);
    }/*
    Este es un comentario
    */
     
}
