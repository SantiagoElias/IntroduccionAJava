/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01;

/**
 *
 * @author chant
 */
public class JavaIntrro01DeteccionDeErrores1_1 
{
    public static void main(String[] args) 
    {
    int numero = 48;
    double decimales = 3.55;
    boolean bandera = false;
    }
}


