/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01;

/**
 *
 * @author chant
 */
public class JavaIntrro01DeteccionDeErrores1 
{
    public static void main(String[] args) 
    {
    String nombre;
    boolean bandera;
    char caracter;
    }
}


