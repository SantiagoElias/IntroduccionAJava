/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01;

/**
 *
 * @author chant
 */
public class Prueba1 
{
    public static void main(String[] args) 
    {
        String nombre = "Mariano";
        int numero = 10;
        double decimales = 40.5;
    }
}
