/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01;

/**
 *
 * @author chant
 */
public class Prueba2 
{
    public static void main(String[] args) 
    {
        int num1 = 5;
        int num2 = 5;
        int suma = num1 + num2;
        double division = num1 / num2;
        boolean logico = num2 < num1;
        num1++;
        System.out.println("num1:"+num1+" num2:"+num2+" suma:"+suma+" division:"+division+" logico:"+logico);
    }
}
