/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01_ej4;

import java.util.Scanner;

/**
 *
 * @author chant
 */
public class JavaIntro01_Ej4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Dada una cantidad de grados centígrados se debe mostrar su
        //equivalente en grados Fahrenheit. La fórmula correspondiente es: F = 32
        //+ (9 * C / 5).
        Scanner leer = new Scanner(System.in);
        float F;
        float C;
        System.out.println("Ingrese los grados en Celsius:");
        C=leer.nextFloat();
        F=32+(9*C/5);
        System.out.println("Los grados en Farenheit son: "+F+"°F");
    }
    
}
