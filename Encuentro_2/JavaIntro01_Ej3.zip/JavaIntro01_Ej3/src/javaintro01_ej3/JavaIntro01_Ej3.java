/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaintro01_ej3;

import java.util.Scanner;

/**
 *
 * @author chant
 */
public class JavaIntro01_Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Escribir un programa que pida una frase y la muestre toda en mayúsculas
        //y después toda en minúsculas.
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese su nombre:");
        String nombre = leer.next();
        System.out.println("Su nombre en mayusculas: "+nombre.toUpperCase());
        System.out.println("Su nombre en minusculas: "+nombre.toLowerCase());
    }
    
}
